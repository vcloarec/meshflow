# -*- coding: utf-8 -*-
"""

Description of example


"""
import initExample ## Add path to library (just for examples; you do not need this)

import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtGui, mkQApp
import numpy as np

app = mkQApp()

# win.setWindowTitle('pyqtgraph example: ____')

if __name__ == '__main__':
    pg.exec()
